<div class="sidebar">
    <h2>Medicine Management</h2>
    <ul class="menu">
        <li><a href="<?php echo base_url();?>/dashboard">Dashboard</a></li>
        <li><a href="<?php echo base_url();?>medicine/">Medicine</a></li>
        <li><a href="<?php echo base_url();?>medicine/medicine_stock">Medicine In Stock</a></li>
    </ul>
</div>
